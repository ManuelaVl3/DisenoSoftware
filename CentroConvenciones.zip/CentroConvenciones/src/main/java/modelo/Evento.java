/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import java.time.LocalTime;
import java.util.Date;
import util.LSE;

/**
 *
 * @author manue
 */
public class Evento implements Serializable{

    private LocalTime horaInicio;
    private LocalTime horaFin;
    private String nombreE;
    private int aforo;
    LSE<Persona> listaPersonas;
    private Date fecha;

    public Evento(LocalTime horaInicio, LocalTime horaFin, String nombreE, int aforo, LSE<Persona> listaPersonas, Date fecha) {

        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.nombreE = nombreE;
        this.aforo = aforo;
        this.listaPersonas = listaPersonas;
        this.fecha = fecha;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(LocalTime horaFin) {
        this.horaFin = horaFin;
    }

    public String getNombreE() {
        return nombreE;
    }

    public void setNombreE(String nombreE) {
        this.nombreE = nombreE;
    }

    public int getAforo() {
        return aforo;
    }

    public void setAforaMax(int aforaMax) {
        this.aforo = aforo;
    }

    public LSE<Persona> getListaPersonas() {
        return listaPersonas;
    }

    public void setListaPersonas(LSE<Persona> listaPersonas) {
        this.listaPersonas = listaPersonas;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    

}
