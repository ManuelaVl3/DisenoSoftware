/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author manue
 */
public class Casilla implements Serializable {

    public static final String DISPONIBLE = "Disponible";

    public static final String OCUPADO = "Ocupado";

    private String estado;

    private Auditorio auditorio;

    public Casilla() {

        this.estado = DISPONIBLE;
        this.auditorio = null;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Auditorio getAuditorio() {
        return auditorio;
    }

    public void setAuditorio(Auditorio auditorio) {
        this.auditorio = auditorio;
    }

}
