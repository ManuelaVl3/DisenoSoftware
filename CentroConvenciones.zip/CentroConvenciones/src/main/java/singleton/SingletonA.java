/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package singleton;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import modelo.Casilla;

/**
 *
 * @author manue
 */
public class SingletonA {
    
    private static SingletonA INSTANCIA = new SingletonA();
    private Casilla[][] casillas;
    
    public SingletonA(){
        
        casillas = leer();
    }
    
    public static SingletonA getInstancia(){
        return INSTANCIA;
    }
    
    public Casilla[][] getCasilla(){
        return this.casillas;
    }
    
    public Casilla[][] leer(){
        try{
            FileInputStream archivo = new FileInputStream("auditorio.dat");
            ObjectInputStream lector = new ObjectInputStream(archivo);
            Casilla[][] casillas = (Casilla[][]) lector.readObject();
            return casillas;
        } catch(IOException | ClassNotFoundException ex){
            Casilla[][] cas = new Casilla[3][5];
            // Crear como en la matriz
            return cas;
        }
    }
    
    public void escribirObjeto(Casilla[][] lista){
        try{
            FileOutputStream archivo = new FileOutputStream("auditorio.dat");
            ObjectOutputStream escritor = new ObjectOutputStream(archivo);
            escritor.writeObject(lista);
        } catch(IOException ex){
            ex.printStackTrace();
        }
    }
}

