/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.io.Serializable;

/**
 *
 * @author manue
 */
public class LSE<S> implements Serializable {

    private Nodo<S> primero;
    private int size;

    public LSE() {

        this.primero = null;
        this.size = 0;
    }

    public int size() {
        return size;
    }

    /* Importante para añadir datos es la Referencia*/
    public void add(S dato) {
        Nodo<S> nuevo = new Nodo<>(dato);
        if (primero == null) {
            primero = nuevo;
        } else {
            Nodo<S> aux = primero;
            while (aux.getNodoSig() != null) {
                aux = aux.getNodoSig();
            }
            aux.setNodoSig(nuevo);
        }
        size++;
    }

    public S get(int index) {
        /*El indice debe ser mayor o igual a cero y menor que el tamaño*/
        if (/*size>0 &&*/index >= 0 && index < size) {
            if (index == 0) {
                return primero.getDato();
            } else {
                Nodo<S> aux = primero;
                int cont = 0;
                while (cont < index) {
                    aux = aux.getNodoSig();
                    cont++;
                }
                return aux.getDato();
            }
        } else {
            throw new ArrayIndexOutOfBoundsException();
        }

    }

    public void remove(int index) {
        if (index < size && index >= 0) {
            if (primero == null) {
                return;
            } else {
                if (index == 0) {
                    if (primero.getNodoSig() != null) {
                        primero = primero.getNodoSig();
                        size--;
                        return;
                    } else {
                        size--;
                        primero = null;
                        return;
                    }
                } else {
                    int cont = 1;
                    Nodo anterior = primero;
                    Nodo actual = anterior.getNodoSig();
                    Nodo siguiente = actual.getNodoSig();
                    while (cont < index) {
                        cont++;
                        anterior = actual;
                        actual = siguiente;
                        siguiente = siguiente.getNodoSig();
                    }
                    anterior.setNodoSig(actual.getNodoSig());
                    size--;
                    return;
                }
            }
        }
        throw new IndexOutOfBoundsException("Posición fuera de rango");
    }

    public void insertAny(int index, int dato) {
        Nodo nuevoN = new Nodo(dato);
        if (index <= size && index >= 0) {
            if (primero == null) {
                primero = nuevoN;
            } else {
                if (index == 0) {
                    nuevoN.setNodoSig(primero);
                    primero = nuevoN;
                    size++;
                    return;
                } else {
                    Nodo anterior = primero;
                    Nodo actual = anterior.getNodoSig();
                    int cont = 1;
                    while (cont < index) {
                        cont++;
                        anterior = actual;
                        actual = actual.getNodoSig();
                    }
                    anterior.setNodoSig(nuevoN);
                    nuevoN.setNodoSig(actual);
                    size++;
                }
            }
        }
    }

}
