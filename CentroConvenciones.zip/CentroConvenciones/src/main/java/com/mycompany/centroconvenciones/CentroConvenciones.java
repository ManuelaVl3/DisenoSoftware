/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.centroconvenciones;

import controlador.CoAuditorio;
import controlador.CoEvento;
import controlador.CoMatriz;
import controlador.CoPersona;
import vistas.VistaMatriz;

/**
 *
 * @author manue
 */
public class CentroConvenciones {

    public static void main(String[] args) {
        CoAuditorio co = new CoAuditorio();
        CoEvento ce = new CoEvento();
        CoMatriz cm = new CoMatriz();
        CoPersona cp = new CoPersona();
        
        VistaMatriz vm = new VistaMatriz(co, ce, cm, cp);
        vm.setVisible(true);
        
    }
}
