/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Auditorio;
import modelo.Casilla;
import singleton.SingletonA;

/**
 *
 * @author manue
 */
public class CoMatriz {

    Casilla[][] casillas;
    
    public CoMatriz() {

        casillas = SingletonA.getInstancia().getCasilla(); 
                              
        if (casillas[0][0] == null) {
            inicializarCas();
        }

    }

    public void inicializarCas() {
        for (int i = 0; i < casillas.length; i++) {
            for (int j = 0; j < casillas[i].length; j++) {
                casillas[i][j] = new Casilla();
            }
        }

    }

    public void guardarMatrizEnSingleton() {
        SingletonA.getInstancia().escribirObjeto(casillas);
    }

    public Casilla obtenerCasilla(int fila, int columna) {
        return casillas[fila][columna];
    }

    public void guardarAuditorio(int fila, int columna, Auditorio a, String estado) {
        casillas[fila][columna].setAuditorio(a);
        casillas[fila][columna].setEstado(estado);
        guardarMatrizEnSingleton();
    }
    
    public Casilla[][] obtenerMatriz(){
        return casillas;
    }

}
