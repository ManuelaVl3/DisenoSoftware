/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import modelo.Auditorio;
import modelo.Casilla;
import modelo.Evento;
import modelo.Persona;
import util.LSE;

/**
 *
 * @author manue
 */
public class CoEvento {

    LSE<Evento> listaEventos;

    public CoEvento() {

        listaEventos = new LSE<>();

    }

    public boolean validarP(LocalTime horaI, LocalTime horaF, Date fecha, String cedula, Casilla[][] casilla) {
        for (int i = 0; i < casilla.length; i++) {

            for (int j = 0; j < casilla[i].length; j++) {
                if (casilla[i][j] != null) {

                    Auditorio au = casilla[i][j].getAuditorio();
                    if (au != null) {
                        Evento evento = au.getEvento();
                        if (evento != null) {
                            LSE<Persona> listaPersonas = evento.getListaPersonas();

                            for (int k = 0; k < listaPersonas.size(); k++) {

                                if (listaPersonas.get(k).getCedula().equals(cedula)) {

                                    if (evento.getFecha().equals(fecha)) {

                                        if ((horaI.isAfter(evento.getHoraInicio())
                                                && horaI.isBefore(evento.getHoraFin()))
                                                || (horaF.isAfter(evento.getHoraInicio())
                                                && horaF.isBefore(evento.getHoraFin()))) {

                                            return false;
                                        }
                                    } else {
                                    }
                                }
                            }
                        } else {
                        }
                    } else {
                    }

                } else {
                }

            }
        }

        return true;
    }

    public LocalTime pasarStringLocal(String hora) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        LocalTime tiempo = LocalTime.parse(hora, formatter);
        return tiempo;
    }

    public String pasarLocalString(LocalTime tiempo) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");

        String tiempoString = tiempo.format(formatter);

        return tiempoString;
    }

    public String pasarDateString(Date fecha) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        String fechaString = sdf.format(fecha);

        return fechaString;
    }

    public String crearEvento(Evento evento) {
        listaEventos.add(evento);
        return "El evento se creó correctamente";
    }

}
