/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Auditorio;
import util.LSE;

/**
 *
 * @author manue
 */
public class CoAuditorio {
    
    LSE<Auditorio> listaAuditorio;
    
    public CoAuditorio(){
        
        listaAuditorio = new LSE<>();
        
    }
    
    public void crearEvento(Auditorio auditorio) {
        listaAuditorio.add(auditorio);
    }
}
