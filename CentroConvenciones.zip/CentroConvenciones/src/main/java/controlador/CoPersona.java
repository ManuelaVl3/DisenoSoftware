/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.time.LocalTime;
import modelo.Persona;
import util.LSE;

/**
 *
 * @author manue
 */
public class CoPersona {

    LSE<Persona> listaPersonas;

    public CoPersona() {

        this.listaPersonas = new LSE<>();
    }
   
    public Persona buscarPersona(String cedula, LSE<Persona> listaPersonas) {
        for (int i = 0; i < listaPersonas.size(); i++) {
            if (listaPersonas.get(i).getCedula().equals(cedula)) {
                return listaPersonas.get(i);
            }
        }
        return null;
    }

    public String crearPersona(Persona persona, LSE<Persona> listaPersonas) {
        Persona aux = buscarPersona(persona.getCedula(), listaPersonas);
        if (aux == null) {
            return "La persona se agregó al evento";
        }
        return "";
    }
}

